﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace MM.Core
{
    public class Class1
    {
    //    public static string EncryptString(string message, string KeyString, string IVString)
    //    {
    //        byte[] Key = ASCIIEncoding.UTF8.GetBytes(KeyString);
    //        byte[] IV = ASCIIEncoding.UTF8.GetBytes(IVString);

    //        string encrypted = null;
    //        RijndaelManaged rj = new RijndaelManaged();
    //        rj.Key = Key;
    //        rj.IV = IV;
    //        rj.Mode = CipherMode.CBC;

    //        try
    //        {
    //            MemoryStream ms = new MemoryStream();

    //            using (CryptoStream cs = new CryptoStream(ms, rj.CreateEncryptor(Key, IV), CryptoStreamMode.Write))
    //            {
    //                using (StreamWriter sw = new StreamWriter(cs))
    //                {
    //                    sw.Write(message);
    //                    sw.Close();
    //                }
    //                cs.Close();
    //            }
    //            byte[] encoded = ms.ToArray();
    //            encrypted = Convert.ToBase64String(encoded);

    //            ms.Close();
    //        }
    //        catch (CryptographicException e)
    //        {
    //            Console.WriteLine("A Cryptographic error occurred: {0}", e.Message);
    //            return null;
    //        }
    //        catch (UnauthorizedAccessException e)
    //        {
    //            Console.WriteLine("A file error occurred: {0}", e.Message);
    //            return null;
    //        }
    //        catch (Exception e)
    //        {
    //            Console.WriteLine("An error occurred: {0}", e.Message);
    //        }
    //        finally
    //        {
    //            rj.Clear();
    //        }
    //        return encrypted;
    //    }


    //    public static string Decrypt(string cipherData, string keyString, string ivString)
    //    {
    //        byte[] key = Encoding.UTF8.GetBytes(keyString);
    //        byte[] iv = Encoding.UTF8.GetBytes(ivString);

    //        try
    //        {
    //            using (var rijndaelManaged =
    //                   new RijndaelManaged { Key = key, IV = iv, Mode = CipherMode.CBC })
    //            using (var memoryStream =
    //                   new MemoryStream(Convert.FromBase64String(cipherData)))
    //            using (var cryptoStream =
    //                   new CryptoStream(memoryStream,
    //                       rijndaelManaged.CreateDecryptor(key, iv),
    //                       CryptoStreamMode.Read))
    //            {
    //                return new StreamReader(cryptoStream).ReadToEnd();
    //            }
    //        }
    //        catch (CryptographicException e)
    //        {
    //            Console.WriteLine("A Cryptographic error occurred: {0}", e.Message);
    //            return null;
    //        }
    //        // You may want to catch more exceptions here...
    //    }
    }
}
