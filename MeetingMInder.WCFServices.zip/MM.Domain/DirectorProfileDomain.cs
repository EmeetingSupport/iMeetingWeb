﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MM.Domain
{
    #region "Director's Profile"

    /// <summary>
    /// Property Of DirectorsProfile 
    /// </summary>
  public  class DirectorProfileDomain
    {
      public Guid DirectorId { get; set; }
      public string DirectorName { get; set; }
      public string DirectorDescription { get; set; }
      public string CompnayUrl { get; set; }
      public Guid EntityId { get; set; }
      public DateTime CreatedOn { get; set; }
      public Guid CreatedBy {get; set;}
      public DateTime UpdatedOn { get; set; }
      public Guid UpdatedBy { get; set; }

    }

    #endregion
}
